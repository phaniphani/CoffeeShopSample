__theranos = {"lat": "37.408235", "lng": "-122.152088", "name": " Theranos Head Quarters", "address": "1701 Page Mill Road Palo Alto, CA 94304"};
__heapSize = 7;
p1 = {lat: function(){return __theranos.lat;}, lng: function() {return __theranos.lng}};
var infoWindows = [];
var markers = [];
function initialize() {
	var theranosLatLng = new google.maps.LatLng(__theranos.lat, __theranos.lng);  
	var mapOptions = {
		zoom: 14,
		center: theranosLatLng
	};
	var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
	addHeadQuarters(theranosLatLng, __theranos, map);
	
	$.getJSON("locations.json", function(data){
	  var shopList = [];
	  data.results.forEach(processJsonList, shopList);
	  shopList.forEach(addMarker, map);
	  for (var k = 0; k < __heapSize; k++) {
	    google.maps.event.addListener(markers[k], 'click', openWindow(markers[k], k, shopList[k].distance, shopList[k].mesaure));
	  }
	});
}

var openWindow = function (marker, k, distance, measure) {
  return function () {
    for (var i = 0; i < __heapSize; i++) {
      if (infoWindows[i]) {
        infoWindows[i].close();
      }
    }
    infoWindows[k].open(marker.get('map'), marker);
    eventWrapper(infoWindows[k], distance, measure, k);
  };
};

function eventWrapper(infoWindow, distance, measure, index) {
    google.maps.event.addListener(infoWindow,'domready',function(){
     google.maps.event.addDomListener(document.getElementById("metric"+index),
      'click',
       function(e){
            if (infoWindow.measure === 'Kilometers') {
              display = (distance/1609.43).toFixed(2, 10);
              measure = "Miles";
              infoWindow.measure = "Miles";
            } else {
              display = (distance/1000).toFixed(2, 10);
              measure = "Kilometers";
              infoWindow.measure = "Kilometers";
            }
            document.getElementById("metric"+index).innerHTML = '<a href=# id = "metric' + index + '">'  
                                                            + display + ' ' + measure + '</a>' + '</b></p>';
            console.log(e);
        });
      console.clear();
    });
    
}

function addHeadQuarters (latlng, place, map) {
  marker = new google.maps.Marker({
		position: latlng,
		map: map,
		title: place.address
	});
}

function addMarker(element, index, array) {
 var iconBase = 'https://maps.google.com/mapfiles/kml/shapes/';
  var icons = {
    "coffeeShop": {
      icon: iconBase + 'coffee.png'
    }
  };
  
  var image = new google.maps.MarkerImage(
        icons[element.type].icon,
        null, /* size is determined at runtime */
        null, /* origin is 0,0 */
        null, /* anchor is bottom center of the scaled image */
        new google.maps.Size(40, 40)
      );  
  marker = new google.maps.Marker({
		position: new google.maps.LatLng(element.latlong.split(',')[0], element.latlong.split(',')[1]),
		map: this,
		icon: image,
		title: element.address
	});
  var rating="";
  for (var i = 0; i < element.rating; i++) {
    rating += '<li class="cards-rating-star"></li>';
  }
  while (i < 5) {
    rating += '<li class="cards-rating-star cards-rating-star-empty"></li>';
    i++;
  }
  var distance = (element.distance / 1609.43).toFixed(2, 10);
  var shopDetails = '<div id="siteNotice">'+
    '</div>'+
    '<div id="bodyContent">'+
    '<p><b>'+element.name + '</b></p>' +
    '<p><b>'+element.address + '</b></p>' +
    '<p><b>'+ 'Distance from Theranos: ' + '<a href=# id = "metric' +  index + '">' + distance +' '+ "Miles" + '</a>' + '</b></p>' +
    '<p><b>'+rating + '</b></p>'+
    '</div>'+
    '</div>';
  markers.push(marker);
  createInfoWindow(markers[index], shopDetails);
}
    
var createInfoWindow = function() {
  return function (marker, message) {
    infoWindows.push(new google.maps.InfoWindow( {
    content: message
    }));
  };
}();

function processJsonList(element, index) {
  latitude = element.latlong.split(',')[0];
  longitude = element.latlong.split(',')[1];
  p2 = {lat: function(){return latitude;}, lng: function(){return longitude;}};
  var d = getDistance(p1, p2);
  element.distance = d;
  element.measure = "Miles";
  var max;
  if (index < __heapSize) {
    element.type = "coffeeShop";
  	this.push(element);
  	if (index === __heapSize - 1) {
  		var i;
  		for (i = (__heapSize - 1)>>1; i >= 0; i--) {
  			buildMaxHeap (this, i);
  		}
  	}
  } else {
  		if (this[0].distance > element.distance) {
  		  element.type = "coffeeShop";
  			this[0] = element;
  			buildMaxHeap(this, 0);
  		}
  	}
}

function buildMaxHeap (shopList, index) {

	if ((index<<1) + 1 > shopList.length - 1) return;
	
	var max = (index<<1) + 1; 
	if (shopList[max + 1] && shopList[max + 1].distance && shopList[max + 1].distance > shopList[max].distance) {
		max = max + 1;
	}
	if (shopList[index].distance < shopList[max].distance) {
		var temp = shopList[max];
    	shopList[max] = shopList[index];
    	shopList[index] = temp;
    	buildMaxHeap(shopList, max);
	}
	return;
}

var getDistance = function(p1, p2) {
	var R = 6378137; // Earth’s mean radius in meter
	var dLat = rad(p2.lat() - p1.lat());
	var dLong = rad(p2.lng() - p1.lng());
	var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
	Math.cos(rad(p1.lat())) * Math.cos(rad(p2.lat())) *
	Math.sin(dLong / 2) * Math.sin(dLong / 2);
	var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
	var d = R * c;
	return d; // returns the distance in meter
};

var rad = function(x) {
	return x * Math.PI / 180;
};

function loadScript() {
  var script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = 'https://maps.googleapis.com/maps/api/js?v=3.exp' +
      '&signed_in=true&callback=initialize';
  document.body.appendChild(script);
}

window.onload = loadScript;